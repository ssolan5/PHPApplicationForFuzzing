<?php

/***************************************************************************
 *   Copyright (C) 2009-2011 by Geo Varghese(www.seopanel.in)  	   *
 *   sendtogeo@gmail.com   												   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


xdebug_start_code_coverage(XDEBUG_CC_UNUSED);
include_once("includes/sp-load.php");
checkLoggedIn();
include_once(SP_CTRLPATH."/adminpanel.ctrl.php");
$controller = New AdminPanelController();
$controller->view->menu = 'adminpanel';

// set site details according to customizer plugin
$custSiteInfo = getCustomizerDetails();
$siteName = !empty($custSiteInfo['site_name']) ? $custSiteInfo['site_name'] : "Seo Panel";
$controller->set('spTitle', "$siteName: User control panel for manage settings");
$controller->set('spDescription', "$siteName user control panel for manage settings");
$controller->set('spKeywords', "$siteName settings,User control panel,manage $siteName settings");
$controller->spTextPanel = $controller->getLanguageTexts('panel', $_SESSION['lang_code']);
$controller->set('spTextPanel', $controller->spTextPanel);
$controller->set('spTextTools', $controller->getLanguageTexts('seotools', $_SESSION['lang_code']));
$info = $_REQUEST;

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
	switch($_POST['sec']){
	}
	
}else{
	switch($_GET['sec']){
		case "newweb":
			$info['start_script'] = 'websites.php?sec=new&check=1';
			$controller->index($info);
			break;
		
		case "myprofile":
			$info['menu_selected'] = 'my-profile';
			$info['start_script'] = 'users.php?sec=my-profile';
			$controller->index($info);
			break;
		
		case "connections":
			$info['menu_selected'] = 'my-profile';
			$info['start_script'] = 'connections.php';
			$controller->index($info);
			break;
		
		case "settings":
			$info['menu_selected'] = 'settings';
			$info['start_script'] = 'settings.php';
			$controller->index($info);
			break;
		
		case "moz-settings":
			$info['menu_selected'] = 'settings';
			$info['start_script'] = 'settings.php?category=moz';
			$controller->index($info);
			break;
		
		case "google-settings":
			$info['menu_selected'] = 'settings';
			$info['start_script'] = 'settings.php?category=google';
			$controller->index($info);
			break;
			
		case "alerts":
		    $info['menu_selected'] = 'my-profile';
		    $info['start_script'] = 'alerts.php';
		    $controller->index($info);
		    break;

		default:
			$_GET['sec'] = addslashes($_GET['sec']);
			$controller->index($_GET);
			break;
	}
}

$data = xdebug_get_code_coverage();
$newdata = print_r($data,true);

xdebug_stop_code_coverage();
//var_dump(array_search("alerts.ctrl.php", $data));

function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);

	//<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script>
    echo "<script>console.log('" . $output . "' );</script>";
}

	
$path = array(    
    'admin-panel.php' => array( 82, 83, 85, 86, 25),
    'admin.ctrl.php' => array( 151 ),
    'seopanel.ctrl.php' => array( 66 , 67 ),
    'controller.class.php' => array( 120 ),
    'adminpanel.ctrl.php' => array( 153 ),
    'controller.class.php' => array( 120 ),
    'view.class.php' => array( 26, 35 ),
    'adminpanel.ctp.php' => array(17),
    'alerts.php' => array( 24, 54 ),
    'alerts.ctrl.php' => array( 70, 71, 95 ),
    'controller.class.php' => array( 103, 120),
    'view.class.php' => array( 26, 35 ),
    'alert_list.ctp.php' => array( 28 )
);

//computing intersection - 
$intersection = 0;

foreach ($data as $key => $value) {
	
	foreach ($path as $key3 => $value3) {

        /*$y = "alerts.ctrl.php";

        if(strcmp($key3,$y)==0){
            debug_to_console ("found " .$y.  " in path");
        }*/

        if(strpos($key,$key3)!=false){

            debug_to_console ('Found '.$key3.' this is in the path and ');
            $linenumbers = implode(',',$value3);
            debug_to_console( "the lines executed in this file are " . $linenumbers);


            foreach ($value as $key2 => $value2 ){
                foreach ($value3 as $key5){
                    if($key5 == $key2){
                        if($value2 == 1) {
                            //debug_to_console( 'Line number : ' . $key2 . ' was executed !!');
                            debug_to_console ('the line number ' . $key2.' is in the path');
							$intersection=$intersection+1;
                        }
                    
                    }   
                }

                   
            }
        }
    
    }
    
}

echo "<script>var link = document.createElement('link');
link.rel = 'stylesheet';link.type = 'text/css';link.href = 'test.css';document.head.appendChild(link);
$('body').attr('message','".$intersection."');</script>";

?>