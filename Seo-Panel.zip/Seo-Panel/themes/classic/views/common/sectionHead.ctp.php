<div class="SectionHeader">
	<h3>
		<i class="fas fa-angle-double-right fa-xs" style="color: #C7CDD1;"></i> <?php echo $sectionHead?> 
	</h3>
</div>
