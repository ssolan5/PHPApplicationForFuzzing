<div class="Center" style='width:100%;'>
<div class="col" style="padding-left:8px;">
<div class="Block">
<table width="100%" border="0" cellspacing="0px" cellpadding="0">
	<tr>
		<td align="center">
		<p class="dirmsg" style="height: 20px;padding:5px;">
			<font class="error" style="font-size: 13px;"><b><?php echo $msg?></b></font>
		</p>
		</td>
	</tr>
	
	<?php if(!empty($msgButton)) {?>
		<tr>
			<td align="center"><br><?php echo $msgButton?></td>
		</tr>
	<?php }?>
	
</table>

</div>
</div>
</div>
