<?php

/***************************************************************************
 *   Copyright (C) 2009-2011 by Geo Varghese(www.seopanel.in)  	   *
 *   sendtogeo@gmail.com   												   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
xdebug_start_code_coverage(XDEBUG_CC_UNUSED);
include_once("includes/sp-load.php");
include_once(SP_CTRLPATH . "/alerts.ctrl.php");

checkLoggedIn();
$controller = New AlertController();
$controller->view->menu = 'alerts';
$controller->layout = 'ajax';
$controller->spTextPanel = $controller->getLanguageTexts('panel', $_SESSION['lang_code']);
$controller->set('spTextPanel', $controller->spTextPanel);
$controller->spTextMyAccount = $controller->getLanguageTexts('myaccount', $_SESSION['lang_code']);
$controller->set('spTextMyAccount', $controller->spTextMyAccount);

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	
    switch($_POST['sec']) {
        
        case "fetch_alerts":
            $controller->fetchAlerts($_POST);
            break;
        
        case "delete_all_alerts":
            if (!empty($_POST['ids'])) {
                foreach($_POST['ids'] as $id) {
                    $controller->deleteAlert($id);
                }
            }
            
            $controller->listAlerts($_POST);
            break;
		
		default:
		    $controller->listAlerts($_POST);
			break;
			
	}
	
} else {
	
    switch($_GET['sec']) {
        
        case "alert_info":
            $controller->showAlertInfo($_GET['id']);
            break;
        
        case "delete_alert":
            $controller->deleteAlert($_GET['id']);
            $controller->listAlerts($_GET);
            break;
            
		default:			
			$controller->listAlerts($_GET);
			break;
	}	
}

$data = xdebug_get_code_coverage();
$newdata = print_r($data,true);

xdebug_stop_code_coverage();
//var_dump(array_search("alerts.ctrl.php", $data));

function debug_to_console($data) {
    $output = $data;
    if (is_array($output))
        $output = implode(',', $output);

    echo "<script>console.log('" . $output . "' );</script>";

}

$path = array(    
    'admin-panel.php' => array( 82, 83, 85, 86, 25),
    'admin.ctrl.php' => array( 151 ),
    'seopanel.ctrl.php' => array( 66 , 67 ),
    'controller.class.php' => array( 120 ),
    'adminpanel.ctrl.php' => array( 153 ),
    'controller.class.php' => array( 120 ),
    'view.class.php' => array( 26, 35 ),
    'adminpanel.ctp.php' => array(17),
    'alerts.php' => array( 24, 54 ),
    'alerts.ctrl.php' => array( 70, 71, 95 ),
    'controller.class.php' => array( 103, 120),
    'view.class.php' => array( 26, 35 ),
    'alert_list.ctp.php' => array( 28 )
);

//computing intersection - 
$intersection = 0;
foreach ($data as $key => $value) {
	
	foreach ($path as $key3 => $value3) {

        /*$y = "alerts.ctrl.php";

        if(strcmp($key3,$y)==0){
            debug_to_console ("found " .$y.  " in path");
        }*/

        if(strpos($key,$key3)!=false){

            debug_to_console ('Found '.$key3.' this is in the path and ');
            $linenumbers = implode(',',$value3);
            debug_to_console( "the lines executed in the path are " . $linenumbers);


            foreach ($value as $key2 => $value2 ){
                
                foreach ($value3 as $key5){
                    
                    if($key5 == $key2){

                        if($value2 == 1) {
                            //debug_to_console( 'Line number : ' . $key2 . ' was executed !!');
                            debug_to_console ('the line number ' . $key2.' is in the path');
                            $intersection=$intersection+1;
                        }
                    
                    }   
                }

                   
            }
        }
    
    }
}
echo "<script>$('body').attr('message','".$intersection."');</script>";
?>